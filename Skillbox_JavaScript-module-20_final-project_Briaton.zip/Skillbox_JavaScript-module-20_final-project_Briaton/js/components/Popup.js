import Elements from "../Elements.js";

export default class Popup {
  constructor(title, text, secondaryText = "") {
    const popupEl = Elements.create(document.body, "div", "popup");
    const contentEl = Elements.create(popupEl, "div", "popup__content");

    // Заголовок (вверху)
    Elements.create(contentEl, "h4", "popup__heading", { textContent: title });

    // Основной текст (внизу)
    Elements.create(contentEl, "p", "popup__text", { textContent: text });

    // Второй абзац
    if (secondaryText) {
      Elements.create(contentEl, "p", "popup__text popup__text--secondary", {
        textContent: secondaryText,
      });
    }

    // Кнопка закрытия
    const closeBtn = Elements.create(contentEl, "button", "popup__close", {
      type: "button",
    });
    Elements.createSvg(closeBtn, 40, 40, "../../images/sprite.svg#icon-close");
    closeBtn.addEventListener("click", () => popupEl.remove());
  }

  static show(title, text, secondaryText = "") {
    new Popup(title, text, secondaryText);
  }

  static showError(text) {
    new Popup("Упс", "Что-то пошло не так...", text);
  }
}
