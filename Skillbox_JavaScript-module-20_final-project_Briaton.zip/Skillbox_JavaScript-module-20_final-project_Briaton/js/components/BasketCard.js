import Elements from "../Elements.js";

export default class BasketCard {
  #data;
  #element;
  #onRemoveClick;
  #count = 1;
  #countEl;

  constructor(data) {
    this.#data = data;
  }

  get element() {
    return (this.#element ??= this.#createElement());
  }

  get id() {
    return this.#data.id;
  }

  get data() {
    return this.#data;
  }

  get count() {
    return this.#count;
  }

  setupRemoveClick(callback) {
    this.#onRemoveClick = callback;
  }

  increaseCount() {
    this.#count++;
    this.#updateCountText();
  }

  decreaseCount() {
    if (this.#count > 1) {
      this.#count--;
      this.#updateCountText();
    }
  }

  #updateCountText() {
    this.#countEl.textContent = `${this.#count} шт.`;
  }

  #createElement() {
    const cardEl = Elements.create("", "div", "basket-card");

    const imgWrapEl = Elements.create(cardEl, "div", "basket-card__img-wrap");
    Elements.create(imgWrapEl, "img", [], {
      width: 60,
      height: 60,
      src: this.#data.image,
      alt: this.#data.name,
    });

    Elements.create(cardEl, "span", "basket-card__name", {
      textContent: this.#data.name,
    });
    Elements.create(cardEl, "span", "basket-card__price", {
      textContent: `${this.#data.price.new} р.`,
    });

    const quantityWrapEl = Elements.create(
      cardEl,
      "div",
      "basket-card__quantity"
    );

    // счётчик
    this.#countEl = Elements.create(
      quantityWrapEl,
      "span",
      "basket-card__count",
      {
        textContent: `${this.#count} шт.`,
      }
    );

    // обёртка для кнопок
    const controlsEl = Elements.create(
      quantityWrapEl,
      "div",
      "basket-card__controls"
    );

    // кнопка +
    const plusBtn = Elements.create(controlsEl, "button", "basket-card__btn", {
      textContent: "+",
    });

    // кнопка −
    const minusBtn = Elements.create(controlsEl, "button", "basket-card__btn", {
      textContent: "−",
    });

    // обработчики
    plusBtn.addEventListener("click", () => this.increaseCount());
    minusBtn.addEventListener("click", () => this.decreaseCount());

    const closeBtnEl = Elements.create(cardEl, "button", "basket-card__close", {
      type: "button",
    });
    closeBtnEl.addEventListener("click", () => this.#onRemoveClick());
    Elements.createSvg(closeBtnEl, 24, 24, "images/sprite.svg#icon-close");

    return cardEl;
  }
}
